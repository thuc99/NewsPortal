﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NewsPortal.Models;
using Ganss.Xss;
using System.Text.RegularExpressions;

namespace NewsPortal.Controllers
{
    public class ArticlesController : Controller
    {
        private string SanitizeArticleContent(string content)
        {
            var sanitizer = new HtmlSanitizer();

            // Cho phép giữ định dạng chữ, căn lề và màu sắc từ TinyMCE
            sanitizer.AllowedAttributes.Add("style");

            return sanitizer.Sanitize(content ?? string.Empty);
        }

        private string GetPlainText(string html)
        {
            if (string.IsNullOrWhiteSpace(html))
                return string.Empty;

            string text = Regex.Replace(html, "<[^>]*>", " ");
            text = HttpUtility.HtmlDecode(text);
            text = Regex.Replace(text, @"\s+", " ");

            return text.Trim();
        }

        private readonly NewsPortalDBEntities db = new NewsPortalDBEntities();

        private static readonly string[] ValidStatuses = new[]
        {
            "Draft", "Pending", "Published", "Rejected", "Archived"
        };

        private static bool _statusConstraintChecked = false;
        private static readonly object _constraintLock = new object();

        private void EnsureWorkflowStatusConstraint()
        {
            if (_statusConstraintChecked) return;

            lock (_constraintLock)
            {
                if (_statusConstraintChecked) return;

                const string sql = @"
IF OBJECT_ID(N'dbo.Articles', N'U') IS NOT NULL
BEGIN
    DECLARE @dropSql NVARCHAR(MAX) = N'';
    SELECT @dropSql = @dropSql + N'ALTER TABLE dbo.Articles DROP CONSTRAINT [' + REPLACE(cc.name, N']', N']]') + N'];'
    FROM sys.check_constraints cc
    LEFT JOIN sys.columns col
        ON col.object_id = cc.parent_object_id
       AND col.column_id = cc.parent_column_id
    WHERE cc.parent_object_id = OBJECT_ID(N'dbo.Articles')
      AND (col.name = N'Status' OR cc.definition LIKE N'%Status%' OR cc.name IN (N'CK_Articles_Status', N'CK_Articles_Status_Workflow'));

    IF LEN(@dropSql) > 0
        EXEC sp_executesql @dropSql;

    UPDATE dbo.Articles
    SET Status = N'Draft'
    WHERE Status IS NULL
       OR Status NOT IN (N'Draft', N'Pending', N'Published', N'Rejected', N'Archived');

    ALTER TABLE dbo.Articles WITH CHECK
    ADD CONSTRAINT [CK_Articles_Status_Workflow]
    CHECK ([Status] IN (N'Draft', N'Pending', N'Published', N'Rejected', N'Archived'));

    IF COL_LENGTH(N'dbo.Articles', N'RejectionReason') IS NULL
    BEGIN
        ALTER TABLE dbo.Articles ADD [RejectionReason] NVARCHAR(500) NULL;
    END

    IF COL_LENGTH(N'dbo.Articles', N'UserId') IS NULL
    BEGIN
        ALTER TABLE dbo.Articles ADD [UserId] INT NULL;
    END
END";
                db.Database.ExecuteSqlCommand(sql);
                _statusConstraintChecked = true;
            }
        }

        private class ArticleRejectionRow
        {
            public int ArticleID { get; set; }
            public string RejectionReason { get; set; }
        }

        private string GetRejectionReason(int articleId)
        {
            return db.Database.SqlQuery<string>(
                "SELECT RejectionReason FROM dbo.Articles WHERE ArticleID = @p0",
                articleId).FirstOrDefault();
        }

        private void SetRejectionReason(int articleId, string reason)
        {
            object param = string.IsNullOrWhiteSpace(reason) ? (object)DBNull.Value : reason.Trim();
            db.Database.ExecuteSqlCommand(
                "UPDATE dbo.Articles SET RejectionReason = @p0 WHERE ArticleID = @p1",
                param,
                articleId);
        }

        private Dictionary<int, string> GetRejectionReasons(IEnumerable<int> articleIds)
        {
            var result = new Dictionary<int, string>();
            var idList = articleIds == null ? new List<int>() : articleIds.Distinct().ToList();
            if (idList.Count == 0)
                return result;

            string inClause = string.Join(",", idList);
            var rows = db.Database.SqlQuery<ArticleRejectionRow>(
                "SELECT ArticleID, RejectionReason FROM dbo.Articles WHERE ArticleID IN (" + inClause + ") AND RejectionReason IS NOT NULL AND LTRIM(RTRIM(RejectionReason)) <> N''"
            ).ToList();

            foreach (var row in rows)
            {
                result[row.ArticleID] = row.RejectionReason;
            }

            return result;
        }

        private int? GetCurrentUserId()
        {
            string username = Convert.ToString(Session["User"] ?? Session["Admin"]);
            if (string.IsNullOrWhiteSpace(username))
                return null;

            var dbUser = db.Users.FirstOrDefault(u => u.Username == username);
            return dbUser != null ? (int?)dbUser.UserId : null;
        }

        private int? GetArticleOwnerUserId(int articleId)
        {
            return db.Database.SqlQuery<int?>(
                @"SELECT COALESCE(a.UserId, author.UserId)
                  FROM dbo.Articles a
                  LEFT JOIN dbo.Authors author ON author.AuthorID = a.AuthorID
                  WHERE a.ArticleID = @p0",
                articleId).FirstOrDefault();
        }

        private void SetArticleOwnerUserId(int articleId, int? userId)
        {
            if (!userId.HasValue) return;
            db.Database.ExecuteSqlCommand(
                "UPDATE dbo.Articles SET UserId = @p0 WHERE ArticleID = @p1 AND UserId IS NULL",
                userId.Value,
                articleId);
        }

        private List<int> GetVisibleDraftArticleIdsForCurrentReporter()
        {
            int? currentUserId = GetCurrentUserId();
            if (!currentUserId.HasValue)
                return new List<int>();

            return db.Database.SqlQuery<int>(
                @"SELECT a.ArticleID
                  FROM dbo.Articles a
                  LEFT JOIN dbo.Authors author ON author.AuthorID = a.AuthorID
                  WHERE a.Status = N'Draft' AND COALESCE(a.UserId, author.UserId) = @p0",
                currentUserId.Value).ToList();
        }

        private bool CanCurrentUserAccessDraft(int articleId)
        {
            if (IsAdminUser())
                return false;

            if (!IsArticleAuthorRole())
                return false;

            int? currentUserId = GetCurrentUserId();
            if (!currentUserId.HasValue)
                return false;

            int? ownerUserId = GetArticleOwnerUserId(articleId);
            return ownerUserId.HasValue && ownerUserId.Value == currentUserId.Value;
        }
        // Authors may only modify their own articles; Admins and Editors can review all articles.
        private bool CanEditorEditArticle(int articleId)
        {
            if (IsAdminUser())
                return true;

            if (IsEditorUser())
                return db.Articles.Any(a => a.ArticleID == articleId && a.Status == "Pending");

            if (!IsArticleAuthorRole())
                return false;

            int? currentUserId = GetCurrentUserId();
            if (!currentUserId.HasValue)
                return false;

            int? ownerUserId = GetArticleOwnerUserId(articleId);
            return ownerUserId.HasValue && ownerUserId.Value == currentUserId.Value;
        }

        private string GetCurrentRole()
        {
            string username = Convert.ToString(Session["User"] ?? Session["Admin"]);
            if (string.IsNullOrWhiteSpace(username))
                return null;

            var user = db.Users.FirstOrDefault(u => u.Username == username && u.IsActive);
            if (user == null)
            {
                if (Session["Admin"] != null && string.Equals(username, "admin", StringComparison.OrdinalIgnoreCase))
                    return "Admin";

                Session.Remove("Admin");
                Session.Remove("Role");
                return null;
            }

            Session["Role"] = user.Role;
            if (string.Equals(user.Role, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                Session["Admin"] = user.Username;
                Session.Remove("User");
            }
            else
            {
                Session.Remove("Admin");
                Session["User"] = user.Username;
                Session["UserFullName"] = user.FullName;
            }

            return user.Role;
        }

        private bool IsEditorUser()
        {
            return string.Equals(GetCurrentRole(), "Editor", StringComparison.OrdinalIgnoreCase);
        }

        private bool IsAuthorUser()
        {
            return string.Equals(GetCurrentRole(), "Author", StringComparison.OrdinalIgnoreCase);
        }

        private bool IsReaderUser()
        {
            string role = GetCurrentRole();
            return string.Equals(role, "Reader", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "User", StringComparison.OrdinalIgnoreCase);
        }

        private bool IsArticleAuthorRole()
        {
            return IsAuthorUser();
        }

        private bool CanAccessArticleManagement()
        {
            return IsAdminUser() || IsEditorUser() || IsArticleAuthorRole();
        }

        private bool CanCreateArticles()
        {
            return IsAdminUser() || IsArticleAuthorRole();
        }
        private bool IsAdminUser()
        {
            return string.Equals(GetCurrentRole(), "Admin", StringComparison.OrdinalIgnoreCase);
        }

        private bool CanManageArticles()
        {
            return IsAdminUser() || IsEditorUser();
        }

        private bool IsAdminArticleRequest()
        {
            return (Request.AppRelativeCurrentExecutionFilePath ?? string.Empty)
                .StartsWith("~/Admin/Article", StringComparison.OrdinalIgnoreCase);
        }

        private ActionResult RedirectToArticleManagement()
        {
            return RedirectToRoute("AdminArticles", new { action = "Index" });
        }

        // Điều hướng về trang trước đó (nếu hợp lệ), ngược lại quay về Trang chủ
        private ActionResult RedirectBackOrHome(string returnUrl = null)
        {
            if (!string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }

            var sessionReturnUrl = Convert.ToString(Session["ArticleReturnUrl"]);
            Session.Remove("ArticleReturnUrl");

            if (!string.IsNullOrWhiteSpace(sessionReturnUrl) && Url.IsLocalUrl(sessionReturnUrl))
            {
                return Redirect(sessionReturnUrl);
            }

            return new RedirectResult("~/");
        }

        private void RememberPreviousPage(string returnUrl)
        {
            if (!string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl))
            {
                Session["ArticleReturnUrl"] = returnUrl;
                return;
            }

            if (Request.UrlReferrer != null &&
                string.Equals(Request.UrlReferrer.Host, Request.Url.Host, StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(Request.UrlReferrer.AbsolutePath, Request.Url.AbsolutePath, StringComparison.OrdinalIgnoreCase))
            {
                Session["ArticleReturnUrl"] = Request.UrlReferrer.PathAndQuery;
            }
        }

        private ActionResult CheckArticlePermission(string actionLabel)
        {
            if (!CanAccessArticleManagement())
            {
                if (Session["User"] != null)
                {
                    TempData["Error"] = "Bạn không có quyền " + actionLabel + " bài viết. Chức năng này chỉ dành cho Admin, Editor hoặc Author.";
                    return new RedirectResult("~/Articles");
                }

                TempData["Error"] = "Vui lòng đăng nhập tài khoản Admin, Editor hoặc Author trước khi truy cập chức năng này.";
                return new RedirectResult("~/Account/Login");
            }

            if (!IsAdminArticleRequest())
                return RedirectToArticleManagement();

            return null;
        }

        private ActionResult CheckAdminArticlePage()
        {
            if (!IsAdminArticleRequest())
                return null;

            return CheckArticlePermission("quản lý");
        }

        private void ValidateArticleInput(
            Article article,
            HttpPostedFileBase imageFile,
            bool checkStatus = false,
            bool requireImage = false)
        {
            if (article == null)
            {
                ModelState.AddModelError("", "Dữ liệu bài viết không hợp lệ.");
                return;
            }

            article.Title = (article.Title ?? string.Empty).Trim();
            article.Content = (article.Content ?? string.Empty).Trim();

            ModelState.Remove("Title");
            ModelState.Remove("Content");
            ModelState.Remove("Status");

            if (string.IsNullOrWhiteSpace(article.Title))
                ModelState.AddModelError("Title", "Tiêu đề không được để trống.");
            else if (article.Title.Length < 10 || article.Title.Length > 250)
                ModelState.AddModelError("Title", "Tiêu đề phải từ 10 đến 250 ký tự.");

            string plainContent = GetPlainText(article.Content);

            if (string.IsNullOrWhiteSpace(plainContent))
                ModelState.AddModelError("Content", "Nội dung bài viết không được để trống.");
            else if (plainContent.Length < 50 || plainContent.Length > 20000)
                ModelState.AddModelError("Content", "Nội dung bài viết phải từ 50 đến 20000 ký tự.");

            if (checkStatus &&
                !string.IsNullOrEmpty(article.Status) &&
                !ValidStatuses.Contains(article.Status))
            {
                ModelState.AddModelError("Status", "Trạng thái bài viết không hợp lệ.");
            }

            bool hasUploadedImage = imageFile != null && imageFile.ContentLength > 0;
            article.ImageUrl = (article.ImageUrl ?? string.Empty).Trim();

            if (requireImage && !hasUploadedImage && string.IsNullOrWhiteSpace(article.ImageUrl))
            {
                ModelState.AddModelError("ImageUrl", "Vui lòng tải ảnh lên hoặc nhập URL ảnh đại diện.");
            }
            else if (!hasUploadedImage && !string.IsNullOrWhiteSpace(article.ImageUrl))
            {
                Uri imageUri;
                if (article.ImageUrl.Length > 1000 ||
                    !Uri.TryCreate(article.ImageUrl, UriKind.Absolute, out imageUri) ||
                    (imageUri.Scheme != Uri.UriSchemeHttp && imageUri.Scheme != Uri.UriSchemeHttps))
                {
                    ModelState.AddModelError("ImageUrl", "URL ảnh phải bắt đầu bằng http:// hoặc https:// và tối đa 1000 ký tự.");
                }
            }

            // Kiểm tra ảnh nếu người dùng tải lên
            if (imageFile != null && imageFile.ContentLength > 0)
            {
                var ext = (Path.GetExtension(imageFile.FileName) ?? string.Empty)
                    .ToLowerInvariant();

                var allowed = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };

                if (!allowed.Contains(ext))
                {
                    ModelState.AddModelError(
                        "",
                        "Chỉ chấp nhận định dạng ảnh .jpg, .jpeg, .png, .gif, .webp.");
                }
                else if (imageFile.ContentLength > 2 * 1024 * 1024)
                {
                    ModelState.AddModelError(
                        "",
                        "Dung lượng ảnh tối đa là 2MB.");
                }
            }
        }

        public ActionResult Index(string searchString, int? categoryId, int? authorId,
            string status, DateTime? fromDate, DateTime? toDate, int? page)
        {
            EnsureWorkflowStatusConstraint();

            var denied = CheckAdminArticlePage();
            if (denied != null) return denied;

            const int pageSize = 8;
            int requestedPage = page ?? 1;
            bool isAdminManagementRequest = IsAdminArticleRequest();
            bool canManageArticles = isAdminManagementRequest && CanAccessArticleManagement();
            bool isAdminUser = canManageArticles && IsAdminUser();
            bool isEditorUser = canManageArticles && IsEditorUser();
            bool isAuthorUser = canManageArticles && IsAuthorUser();
            bool isReaderUser = canManageArticles && IsReaderUser();

            var query = db.Articles
                .Include(a => a.Categories)
                .Include(a => a.Authors)
                .AsQueryable();

            if (!canManageArticles)
            {
                query = query.Where(a => a.Status == "Published");
            }
            else if (isAdminUser || isEditorUser)
            {
                // Reviewers cannot see unpublished drafts that have not been submitted.
                query = query.Where(a => a.Status != "Draft");

                ViewBag.CountAll = db.Articles.Count(a => a.Status != "Draft" && a.Status != "Archived");
                ViewBag.CountDraft = 0;
                ViewBag.CountPending = db.Articles.Count(a => a.Status == "Pending");
                ViewBag.CountPublished = db.Articles.Count(a => a.Status == "Published");
                ViewBag.CountRejected = db.Articles.Count(a => a.Status == "Rejected");
                ViewBag.CountArchived = isAdminUser ? db.Articles.Count(a => a.Status == "Archived") : 0;
                if (!isAdminUser)
                    query = query.Where(a => a.Status != "Archived");
            }
            else
            {
                // Authors and Readers only see articles owned by their account.
                int? currentUserId = GetCurrentUserId();
                var ownArticleIds = currentUserId.HasValue
                    ? db.Database.SqlQuery<int>(@"
                        SELECT a.ArticleID
                        FROM dbo.Articles a
                        LEFT JOIN dbo.Authors author ON author.AuthorID = a.AuthorID
                        WHERE COALESCE(a.UserId, author.UserId) = @p0", currentUserId.Value).ToList()
                    : new List<int>();

                query = query.Where(a => ownArticleIds.Contains(a.ArticleID) && a.Status != "Archived");

                ViewBag.CountDraft = db.Articles.Count(a => ownArticleIds.Contains(a.ArticleID) && a.Status == "Draft");
                ViewBag.CountPending = db.Articles.Count(a => ownArticleIds.Contains(a.ArticleID) && a.Status == "Pending");
                ViewBag.CountPublished = db.Articles.Count(a => ownArticleIds.Contains(a.ArticleID) && a.Status == "Published");
                ViewBag.CountRejected = db.Articles.Count(a => ownArticleIds.Contains(a.ArticleID) && a.Status == "Rejected");
                ViewBag.CountArchived = 0;
                ViewBag.CountAll = db.Articles.Count(a => ownArticleIds.Contains(a.ArticleID) && a.Status != "Archived");
            }

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                searchString = searchString.Trim();
                if (searchString.Length > 200)
                {
                    searchString = searchString.Substring(0, 200);
                }

                query = query.Where(a => a.Title.Contains(searchString));
            }
            else
            {
                searchString = null;
            }

            if (fromDate.HasValue && toDate.HasValue && fromDate.Value.Date > toDate.Value.Date)
            {
                var tempDate = fromDate;
                fromDate = toDate;
                toDate = tempDate;
                ViewBag.WarningMessage = "Ngày bắt đầu lớn hơn ngày kết thúc nên hệ thống đã tự động điều chỉnh lại khoảng ngày.";
            }

            if (categoryId.HasValue)
                query = query.Where(a => a.CategoryID == categoryId.Value);

            if (authorId.HasValue)
                query = query.Where(a => a.AuthorID == authorId.Value);

            if (canManageArticles && !string.IsNullOrWhiteSpace(status) && ValidStatuses.Contains(status))
                query = query.Where(a => a.Status == status);

            if (fromDate.HasValue)
                query = query.Where(a => a.CreatedDate >= fromDate.Value);

            if (toDate.HasValue)
            {
                var endDate = toDate.Value.Date.AddDays(1);
                query = query.Where(a => a.CreatedDate < endDate);
            }

            var totalArticles = query.Count();
            var totalPages = Math.Max((int)Math.Ceiling((double)totalArticles / pageSize), 1);

            int currentPage = requestedPage;
            if (requestedPage < 1)
            {
                currentPage = 1;
                ViewBag.WarningMessage = "Số trang không hợp lệ, hệ thống đã chuyển về trang đầu tiên.";
            }
            else if (requestedPage > totalPages)
            {
                currentPage = totalPages;
                if (totalArticles > 0)
                {
                    ViewBag.WarningMessage = "Số trang bạn nhập (" + requestedPage + ") vượt quá tổng số trang hiện có (" + totalPages + " trang), hệ thống đã chuyển về trang cuối.";
                }
                else if (requestedPage > 1)
                {
                    ViewBag.WarningMessage = "Trang số " + requestedPage + " không tồn tại.";
                }
            }

            var articles = query
                .OrderByDescending(a => a.CreatedDate)
                .Skip((currentPage - 1) * pageSize)
                .Take(pageSize)
                .ToList()
                .Select(ToArticleViewModel)
                .ToList();

            ViewBag.SearchString = searchString;
            ViewBag.CategoryId = categoryId;
            ViewBag.AuthorId = authorId;
            ViewBag.Status = status;
            ViewBag.FromDate = fromDate;
            ViewBag.ToDate = toDate;
            ViewBag.Categories = db.Categories.OrderBy(c => c.CategoryName).ToList();
            ViewBag.Authors = db.Authors.OrderBy(a => a.AuthorName).ToList();
            ViewBag.CurrentPage = currentPage;
            ViewBag.TotalPages = totalPages;
            ViewBag.TotalArticles = totalArticles;
            ViewBag.CanManageArticles = canManageArticles;
            ViewBag.IsAdminManagement = isAdminManagementRequest;
            ViewBag.IsAdminUser = isAdminUser;
            ViewBag.IsEditorUser = isEditorUser;
            ViewBag.IsAuthorUser = isAuthorUser;
            ViewBag.IsReaderUser = isReaderUser;
            ViewBag.RejectionReasons = canManageArticles
                ? GetRejectionReasons(articles.Select(a => a.Id))
                : new Dictionary<int, string>();

            if (!string.IsNullOrWhiteSpace(searchString) && totalArticles == 0)
            {
                ViewBag.SearchMessage = "Không tìm thấy bài viết nào phù hợp với từ khóa \"" + searchString.Trim() + "\".";
            }

            return View(articles);
        }

        public ActionResult Details(int? id)
        {
            SyncViewAndSaved(id);
            return LoadArticleDetails(id, false);
        }

        [ActionName("View")]
        public ActionResult ViewArticle(int? id)
        {
            SyncViewAndSaved(id);
            return LoadArticleDetails(id, true);
        }

        private void SyncViewAndSaved(int? id)
        {
            if (!id.HasValue || id.Value <= 0) return;

            int artId = id.Value;
            string currentUsername = (Session["User"] ?? Session["Admin"]) as string;
            if (!string.IsNullOrEmpty(currentUsername) && db.Articles.Any(a => a.ArticleID == artId))
            {
                var viewer = db.Users.FirstOrDefault(u => u.Username == currentUsername);
                if (viewer != null)
                {
                    var history = db.ArticleViewHistory.FirstOrDefault(h => h.UserId == viewer.UserId && h.ArticleId == artId);
                    if (history != null)
                    {
                        history.ViewedDate = DateTime.Now;
                    }
                    else
                    {
                        db.ArticleViewHistory.Add(new ArticleViewHistory
                        {
                            UserId = viewer.UserId,
                            ArticleId = artId,
                            ViewedDate = DateTime.Now
                        });
                    }
                    db.SaveChanges();

                    bool isSavedInDb = db.SavedArticles.Any(s => s.UserId == viewer.UserId && s.ArticleId == artId);
                    ViewBag.IsSavedArticle = isSavedInDb;

                    // Đồng bộ lại Cookie theo đúng dữ liệu mới nhất trong SQL
                    var syncedIds = db.SavedArticles
                        .Where(s => s.UserId == viewer.UserId)
                        .OrderByDescending(s => s.SavedDate)
                        .Select(s => s.ArticleId)
                        .ToList();

                    Response.Cookies.Add(new HttpCookie("NewsPortalFavorites", string.Join(",", syncedIds))
                    {
                        Expires = DateTime.Now.AddYears(1),
                        HttpOnly = true
                    });
                    return;
                }
            }

            ViewBag.IsSavedArticle = GetFavoriteIds().Contains(artId);
        }

        private ActionResult LoadArticleDetails(int? id, bool canComment)
        {
            EnsureWorkflowStatusConstraint();

            var denied = CheckAdminArticlePage();
            if (denied != null) return denied;

            if (!id.HasValue || id.Value <= 0)
            {
                TempData["Error"] = "Mã bài viết không hợp lệ.";
                return IsAdminArticleRequest() ? RedirectToArticleManagement() : RedirectToAction("Index");
            }

            int articleId = id.Value;
            var article = db.Articles
                .Include(a => a.Categories)
                .Include(a => a.Authors)
                .FirstOrDefault(a => a.ArticleID == articleId);

            bool hasManagePermission = CanManageArticles();
            bool canManageArticles = IsAdminArticleRequest() && CanAccessArticleManagement();
            if (article == null || (article.Status != "Published" &&
                (!IsAdminArticleRequest() || (!hasManagePermission && !CanEditorEditArticle(article.ArticleID)))))
            {
                TempData["Error"] = "Bài viết bạn tìm không tồn tại hoặc chưa được xuất bản.";
                return IsAdminArticleRequest() ? RedirectToArticleManagement() : RedirectToAction("Index");
            }

            if (article.Status == "Draft" && !IsAdminArticleRequest())
            {
                TempData["Error"] = "Bài viết đang ở trạng thái Bản nháp (Draft) — chỉ người viết bài mới có quyền xem.";
                return IsAdminArticleRequest() ? RedirectToArticleManagement() : RedirectToAction("Index");
            }
            if (article.Status == "Draft" && !CanCurrentUserAccessDraft(article.ArticleID))
            {
                TempData["Error"] = "Bài viết đang ở trạng thái Bản nháp (Draft) — chỉ người viết bài mới có quyền xem.";
                return RedirectToArticleManagement();
            }

            bool isPublished = article.Status == "Published";
            if (canComment && isPublished && !HasViewedRecently(articleId))
            {
                article.ViewCount++;
                db.SaveChanges();
                Response.Cookies.Add(new HttpCookie("NewsPortalViewed_" + articleId, "1")
                {
                    Expires = DateTime.Now.AddHours(1),
                    HttpOnly = true
                });
            }

            ViewBag.Comments = db.Comments
              .Where(c => c.ArticleID == articleId && c.Status == "Approved")
              .OrderByDescending(c => c.CreatedDate)
              .ToList();
            ViewBag.AuthorId = article.AuthorID;
            ViewBag.AuthorName = article.Authors == null ? null : article.Authors.AuthorName;
            ViewBag.RatingCount = db.ArticleRatings.Count(r => r.ArticleID == articleId);
            ViewBag.CanManageArticles = canManageArticles;
            ViewBag.IsAdminManagement = IsAdminArticleRequest();
            ViewBag.IsAdminUser = IsAdminUser() || IsEditorUser();
            ViewBag.IsEditorUser = IsEditorUser();
            ViewBag.IsReaderUser = IsReaderUser();
            ViewBag.CanEditArticle = CanEditorEditArticle(article.ArticleID);
            ViewBag.AverageRating = db.ArticleRatings
                .Where(r => r.ArticleID == articleId)
                .Select(r => (double?)r.Rating)
                .Average() ?? 0;
            ViewBag.IsFavorite = ViewBag.IsSavedArticle != null
                            ? (bool)ViewBag.IsSavedArticle
                            : GetFavoriteIds().Contains(articleId); ViewBag.CanComment = canComment && isPublished;

            var recommendations = db.Articles
                .Include(a => a.Categories)
                .Where(a => a.ArticleID != articleId && a.Status == "Published" && a.CategoryID == article.CategoryID)
                .OrderByDescending(a => a.CreatedDate)
                .Take(4)
                .ToList();

            if (recommendations.Count < 4)
            {
                var existingIds = recommendations.Select(a => a.ArticleID).Concat(new[] { articleId }).ToList();
                recommendations.AddRange(db.Articles
                    .Include(a => a.Categories)
                    .Where(a => a.Status == "Published" && !existingIds.Contains(a.ArticleID))
                    .OrderByDescending(a => a.CreatedDate)
                    .Take(4 - recommendations.Count)
                    .ToList());
            }

            ViewBag.RecommendedArticles = recommendations;

            return View("Details", ToArticleViewModel(article));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddComment(int? articleId, string commenterName, string content)
        {
            if (!articleId.HasValue || articleId.Value <= 0 || !db.Articles.Any(a => a.ArticleID == articleId.Value && a.Status == "Published"))
            {
                TempData["Error"] = "Bài viết không tồn tại hoặc chưa được xuất bản.";
                return RedirectToAction("Index");
            }

            commenterName = (commenterName ?? string.Empty).Trim();
            content = (content ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(commenterName))
            {
                TempData["CommentError"] = "Vui lòng nhập tên của bạn.";
                return RedirectToAction("View", new { id = articleId.Value });
            }

            if (string.IsNullOrWhiteSpace(content))
            {
                TempData["CommentError"] = "Vui lòng nhập nội dung bình luận.";
                return RedirectToAction("View", new { id = articleId.Value });
            }

            if (commenterName.Length > 100 || content.Length > 1000)
            {
                TempData["CommentError"] = "Tên tối đa 100 ký tự và bình luận tối đa 1000 ký tự.";
                return RedirectToAction("View", new { id = articleId.Value });
            }

            string currentUsername = (Session["User"] ?? Session["Admin"]) as string;
            var viewer = !string.IsNullOrEmpty(currentUsername)
                ? db.Users.FirstOrDefault(u => u.Username == currentUsername)
                : null;

            db.Comments.Add(new Comments
            {
                ArticleID = articleId.Value,
                UserId = viewer != null ? (int?)viewer.UserId : null,
                CommenterName = commenterName,
                Content = content,
                CreatedDate = DateTime.Now,
                Status = "Approved"
            });
            db.SaveChanges();

            TempData["CommentSuccess"] = "Bình luận của bạn đã được đăng.";
            return RedirectToAction("View", new { id = articleId.Value });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Rate(int? articleId, int? rating)
        {
            if (!articleId.HasValue || articleId.Value <= 0 || !db.Articles.Any(a => a.ArticleID == articleId.Value && a.Status == "Published"))
            {
                TempData["Error"] = "Bài viết không tồn tại hoặc chưa được xuất bản.";
                return RedirectToAction("Index");
            }

            if (!rating.HasValue || rating.Value < 1 || rating.Value > 5)
            {
                TempData["RatingError"] = "Vui lòng chọn mức đánh giá từ 1 đến 5 sao.";
                return RedirectToAction("View", new { id = articleId.Value });
            }

            db.ArticleRatings.Add(new ArticleRatings
            {
                ArticleID = articleId.Value,
                RaterName = "Ẩn danh",
                Rating = (byte)rating.Value,
                CreatedDate = DateTime.Now
            });
            db.SaveChanges();

            TempData["RatingSuccess"] = "Cảm ơn bạn đã đánh giá bài viết.";
            return RedirectToAction("View", new { id = articleId.Value });
        }

        private bool HasViewedRecently(int articleId)
        {
            return Request.Cookies["NewsPortalViewed_" + articleId] != null;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ToggleFavorite(int? articleId)
        {
            if (!articleId.HasValue || articleId.Value <= 0 || !db.Articles.Any(a => a.ArticleID == articleId.Value && a.Status == "Published"))
            {
                TempData["Error"] = "Bài viết không tồn tại hoặc chưa được xuất bản.";
                return RedirectToAction("Index");
            }

            int artId = articleId.Value;

            string currentUsername = (Session["User"] ?? Session["Admin"]) as string;
            var viewer = !string.IsNullOrEmpty(currentUsername)
                ? db.Users.FirstOrDefault(u => u.Username == currentUsername)
                : null;

            if (viewer != null)
            {
                var existing = db.SavedArticles.FirstOrDefault(s => s.UserId == viewer.UserId && s.ArticleId == artId);
                if (existing != null)
                {
                    db.SavedArticles.Remove(existing);
                    TempData["FavoriteMessage"] = "Đã bỏ lưu bài viết.";
                }
                else
                {
                    db.SavedArticles.Add(new SavedArticles
                    {
                        UserId = viewer.UserId,
                        ArticleId = artId,
                        SavedDate = DateTime.Now
                    });
                    TempData["FavoriteMessage"] = "Đã lưu bài viết vào Tin đã lưu.";
                }
                db.SaveChanges();

                var syncedIds = db.SavedArticles
                    .Where(s => s.UserId == viewer.UserId)
                    .OrderByDescending(s => s.SavedDate)
                    .Select(s => s.ArticleId)
                    .ToList();

                Response.Cookies.Add(new HttpCookie("NewsPortalFavorites", string.Join(",", syncedIds))
                {
                    Expires = DateTime.Now.AddYears(1),
                    HttpOnly = true
                });
            }
            else
            {
                var favoriteIds = GetFavoriteIds();
                if (favoriteIds.Contains(artId))
                {
                    favoriteIds.Remove(artId);
                    TempData["FavoriteMessage"] = "Đã bỏ lưu bài viết.";
                }
                else
                {
                    favoriteIds.Add(artId);
                    TempData["FavoriteMessage"] = "Đã lưu bài viết vào Tin đã lưu.";
                }

                Response.Cookies.Add(new HttpCookie("NewsPortalFavorites", string.Join(",", favoriteIds))
                {
                    Expires = DateTime.Now.AddYears(1),
                    HttpOnly = true
                });
            }

            return RedirectToAction("View", new { id = artId });
        }

        private List<int> GetFavoriteIds()
        {
            var cookie = Request.Cookies["NewsPortalFavorites"];
            if (cookie == null || string.IsNullOrWhiteSpace(cookie.Value))
                return new List<int>();

            return cookie.Value.Split(',')
                .Select(value =>
                {
                    int id;
                    return int.TryParse(value, out id) ? (int?)id : null;
                })
                .Where(id => id.HasValue)
                .Select(id => id.Value)
                .Distinct()
                .ToList();
        }

        public ActionResult Favorites()
        {
            var favoriteIds = GetFavoriteIds();
            string currentUsername = (Session["User"] ?? Session["Admin"]) as string;

            if (!string.IsNullOrEmpty(currentUsername))
            {
                var viewer = db.Users.FirstOrDefault(u => u.Username == currentUsername);
                if (viewer != null)
                {
                    // Gộp các bài lưu tạm trong Cookie vào bảng SavedArticles (SQL) nếu chưa có
                    bool hasNew = false;
                    foreach (var artId in favoriteIds)
                    {
                        bool exists = db.SavedArticles.Any(s => s.UserId == viewer.UserId && s.ArticleId == artId);
                        if (!exists && db.Articles.Any(a => a.ArticleID == artId && a.Status == "Published"))
                        {
                            db.SavedArticles.Add(new SavedArticles
                            {
                                UserId = viewer.UserId,
                                ArticleId = artId,
                                SavedDate = DateTime.Now
                            });
                            hasNew = true;
                        }
                    }
                    if (hasNew) db.SaveChanges();

                    // Lấy toàn bộ bài đã lưu từ SQL và cập nhật ngược lại vào Cookie cho khớp
                    favoriteIds = db.SavedArticles
                        .Where(s => s.UserId == viewer.UserId)
                        .OrderByDescending(s => s.SavedDate)
                        .Select(s => s.ArticleId)
                        .ToList();

                    Response.Cookies.Add(new HttpCookie("NewsPortalFavorites", string.Join(",", favoriteIds))
                    {
                        Expires = DateTime.Now.AddYears(1),
                        HttpOnly = true
                    });
                }
            }

            var articles = db.Articles
                .Include(a => a.Categories)
                .Where(a => favoriteIds.Contains(a.ArticleID) && a.Status == "Published")
                .OrderByDescending(a => a.CreatedDate)
                .ToList()
                .Select(ToArticleViewModel)
                .ToList();

            return View(articles);
        }

        // Upload ảnh được chèn trực tiếp trong nội dung bài viết bằng CKEditor 5.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UploadContentImage(HttpPostedFileBase upload)
        {
            var denied = CheckArticlePermission("tải ảnh lên");
            if (denied != null)
            {
                Response.StatusCode = 403;
                return Json(new
                {
                    uploaded = false,
                    error = "Bạn không có quyền tải ảnh lên."
                });
            }

            if (upload == null || upload.ContentLength <= 0)
            {
                Response.StatusCode = 400;
                return Json(new
                {
                    uploaded = false,
                    error = "Vui lòng chọn ảnh cần tải lên."
                });
            }

            // Ảnh trong nội dung được giới hạn 5MB.
            if (upload.ContentLength > 5 * 1024 * 1024)
            {
                Response.StatusCode = 400;
                return Json(new
                {
                    uploaded = false,
                    error = "Dung lượng ảnh tối đa là 5MB."
                });
            }

            string extension = (Path.GetExtension(upload.FileName) ?? string.Empty)
                .ToLowerInvariant();

            string[] allowedExtensions =
            {
                ".jpg", ".jpeg", ".png", ".gif", ".webp"
            };

            if (!allowedExtensions.Contains(extension))
            {
                Response.StatusCode = 400;
                return Json(new
                {
                    uploaded = false,
                    error = "Chỉ chấp nhận ảnh JPG, JPEG, PNG, GIF hoặc WEBP."
                });
            }

            // Kiểm tra MIME type để hạn chế tệp giả dạng ảnh.
            string contentType = (upload.ContentType ?? string.Empty).ToLowerInvariant();
            string[] allowedContentTypes =
            {
                "image/jpeg", "image/png", "image/gif", "image/webp"
            };

            if (!allowedContentTypes.Contains(contentType))
            {
                Response.StatusCode = 400;
                return Json(new
                {
                    uploaded = false,
                    error = "Loại tệp tải lên không phải định dạng ảnh được hỗ trợ."
                });
            }

            try
            {
                string relativeFolder = "~/Content/Images/Articles/Content/";
                string folder = Server.MapPath(relativeFolder);

                if (string.IsNullOrWhiteSpace(folder))
                    throw new IOException("Không xác định được thư mục lưu ảnh.");

                Directory.CreateDirectory(folder);

                string fileName = Guid.NewGuid().ToString("N") + extension;
                string filePath = Path.Combine(folder, fileName);

                upload.SaveAs(filePath);

                string imageUrl = Url.Content(relativeFolder + fileName);

                return Json(new
                {
                    uploaded = true,
                    url = imageUrl
                });
            }
            catch (Exception)
            {
                Response.StatusCode = 500;
                return Json(new
                {
                    uploaded = false,
                    error = "Không thể lưu ảnh lên máy chủ. Vui lòng thử lại."
                });
            }
        }

        public ActionResult Create(string returnUrl)
        {
            EnsureWorkflowStatusConstraint();

            var denied = CheckArticlePermission("thêm");
            if (denied != null) return denied;
            if (!CanCreateArticles()) return RedirectToArticleManagement();

            RememberPreviousPage(returnUrl);

            ViewBag.IsAdminManagement = true;
            ViewBag.IsAdminUser = IsAdminUser() || IsEditorUser();
            ViewBag.IsEditorUser = IsEditorUser();
            ViewBag.IsReaderUser = IsReaderUser();
            ViewBag.ReturnUrl = returnUrl;
            PopulateCreateCategories(null);
            return View(new Article());
        }

        private void PopulateCreateCategories(int? selectedCategoryId)
        {
            ViewBag.CategoryId = new SelectList(
                db.Categories.OrderBy(c => c.CategoryName).ToList(),
                "CategoryID",
                "CategoryName",
                selectedCategoryId);
        }

        [HttpPost]
        [ValidateInput(false)]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Article article, HttpPostedFileBase imageFile, string submitAction, string returnUrl)
        {
            EnsureWorkflowStatusConstraint();

            var denied = CheckArticlePermission("thêm");
            if (denied != null) return denied;
            if (!CanCreateArticles()) return RedirectToArticleManagement();

            bool isAdmin = IsAdminUser();
            ViewBag.IsAdminManagement = true;
            ViewBag.IsAdminUser = isAdmin || IsEditorUser();
            ViewBag.IsEditorUser = IsEditorUser();
            ViewBag.IsReaderUser = IsReaderUser();
            ViewBag.ReturnUrl = returnUrl;

            if (article != null)
            {
                article.Content = SanitizeArticleContent(article.Content);
            }

            ModelState.Remove("AuthorId");
            ModelState.Remove("Summary");
            ModelState.Remove("Image");

            PopulateCreateCategories(article == null ? null : article.CategoryId);
            ValidateArticleInput(article, imageFile, false, true);

            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                TempData["Error"] = "Không thể tạo bài viết: " + string.Join(" | ", errors);
                return View(article);
            }

            var category = db.Categories.FirstOrDefault(c => c.CategoryID == article.CategoryId.Value);
            if (category == null)
            {
                ModelState.AddModelError("CategoryId", "Danh mục đã chọn không tồn tại.");
                PopulateCreateCategories(article.CategoryId);
                return View(article);
            }

            var currentUsername = Session["User"] as string ?? Session["Admin"] as string;
            if (string.IsNullOrWhiteSpace(currentUsername))
            {
                ModelState.AddModelError("", "Vui lòng đăng nhập trước khi thêm bài viết.");
                return View(article);
            }

            var currentUser = db.Users.FirstOrDefault(u => u.Username == currentUsername);
            if (currentUser == null)
            {
                ModelState.AddModelError("", "Tài khoản người dùng không hợp lệ.");
                return View(article);
            }

            var displayName = !string.IsNullOrWhiteSpace(currentUser.FullName)
                ? currentUser.FullName
                : currentUser.Username;

            var author = IsArticleAuthorRole()
                ? db.Authors.FirstOrDefault(a => a.UserId == currentUser.UserId)
                : db.Authors.FirstOrDefault(a =>
                    a.AuthorName == displayName ||
                    a.AuthorName == currentUser.Username ||
                    (!string.IsNullOrEmpty(currentUser.Email) && a.Email == currentUser.Email));

            if (author == null)
            {
                if (!IsAuthorUser())
                {
                    ModelState.AddModelError("", "Tài khoản Author chưa được liên kết với hồ sơ tác giả. Vui lòng liên hệ quản trị viên.");
                    return View(article);
                }

                var existingUnlinkedAuthors = string.IsNullOrWhiteSpace(currentUser.Email)
                    ? new List<Author>()
                    : db.Authors.Where(a => a.Email == currentUser.Email && !a.UserId.HasValue).ToList();
                if (existingUnlinkedAuthors.Count == 1)
                {
                    author = existingUnlinkedAuthors[0];
                    author.UserId = currentUser.UserId;
                    author.AuthorName = displayName;
                }
                else
                {
                    author = new Author
                    {
                        AuthorName = displayName,
                        Email = currentUser.Email,
                        UserId = currentUser.UserId
                    };

                    db.Authors.Add(author);
                }
                db.SaveChanges();
            }

            if (author == null)
            {
                ModelState.AddModelError("", "Không thể tạo hoặc tìm thấy tác giả.");
                return View(article);
            }

            string targetStatus;
            if (IsArticleAuthorRole())
            {
                targetStatus = string.Equals(submitAction, "Draft", StringComparison.OrdinalIgnoreCase)
                    ? "Draft"
                    : "Pending";
            }
            else
            {
                if (string.Equals(submitAction, "Draft", StringComparison.OrdinalIgnoreCase))
                    targetStatus = "Draft";
                else if (string.Equals(submitAction, "Pending", StringComparison.OrdinalIgnoreCase))
                    targetStatus = "Pending";
                else
                    targetStatus = "Published";
            }

            string imageUrl = SaveImage(imageFile);
            if (string.IsNullOrWhiteSpace(imageUrl))
                imageUrl = article.ImageUrl;

            if (string.IsNullOrWhiteSpace(imageUrl))
            {
                ModelState.AddModelError("ImageUrl", "Vui lòng chọn ảnh đại diện hoặc nhập URL ảnh hợp lệ.");
                return View(article);
            }

            var newArticle = new Articles
            {
                CategoryID = category.CategoryID,
                AuthorID = author.AuthorID,
                Title = article.Title,
                Summary = CreateSummary(article.Content),
                Content = article.Content,
                CreatedDate = DateTime.Now,
                Status = targetStatus,
                ImageUrl = imageUrl,
                ViewCount = 0
            };
            db.Articles.Add(newArticle);
            db.SaveChanges();
            SetArticleOwnerUserId(newArticle.ArticleID, GetCurrentUserId());

            if (targetStatus == "Draft")
                TempData["Success"] = "Đã lưu bài viết dưới dạng Bản nháp (Draft).";
            else if (targetStatus == "Pending")
                TempData["Success"] = "Đã gửi bài viết chờ Admin phê duyệt (Pending).";
            else
                TempData["Success"] = "Đã xuất bản bài viết mới lên trang chủ (Published).";

            return RedirectBackOrHome(returnUrl);
        }

        public ActionResult Edit(int? id, string returnUrl = null)
        {
            EnsureWorkflowStatusConstraint();

            var denied = CheckArticlePermission("chỉnh sửa");
            if (denied != null) return denied;

            RememberPreviousPage(returnUrl);

            bool isAdmin = IsAdminUser();
            ViewBag.IsAdminManagement = true;
            ViewBag.IsAdminUser = isAdmin || IsEditorUser();
            ViewBag.IsEditorUser = IsEditorUser();
            ViewBag.ReturnUrl = returnUrl;

            if (!id.HasValue || id.Value <= 0)
            {
                TempData["Error"] = "Mã bài viết cần chỉnh sửa không hợp lệ.";
                return RedirectToArticleManagement();
            }

            var article = db.Articles.Find(id.Value);
            if (article == null)
            {
                TempData["Error"] = "Bài viết cần chỉnh sửa không tồn tại hoặc đã bị xóa.";
                return RedirectToArticleManagement();
            }

            if (!CanEditorEditArticle(article.ArticleID))
            {
                TempData["Error"] = "Bạn chỉ có quyền chỉnh sửa bài viết của chính mình.";
                return RedirectToArticleManagement();
            }
            PopulateCreateCategories(article.CategoryID);
            ViewBag.RejectionReason = GetRejectionReason(article.ArticleID);
            return View(ToArticleViewModel(article));
        }

        [HttpPost]
        [ValidateInput(false)]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Article article, HttpPostedFileBase imageFile, string submitAction, string returnUrl = null, string rejectionReason = "")
        {
            EnsureWorkflowStatusConstraint();

            var denied = CheckArticlePermission("chỉnh sửa");
            if (denied != null) return denied;

            bool isAdmin = IsAdminUser();
            bool isEditorUser = IsEditorUser();
            bool isReviewer = isAdmin || isEditorUser;
            ViewBag.IsAdminManagement = true;
            ViewBag.IsAdminUser = isReviewer;
            ViewBag.IsEditorUser = isEditorUser;
            ViewBag.ReturnUrl = returnUrl;

            var existing = article != null ? db.Articles.Find(article.Id) : null;
            if (existing == null)
            {
                TempData["Error"] = "Bài viết cần chỉnh sửa không tồn tại hoặc đã bị xóa trước đó.";
                return RedirectToArticleManagement();
            }
            if (!CanEditorEditArticle(existing.ArticleID))
            {
                TempData["Error"] = "Bạn chỉ có quyền chỉnh sửa bài viết của chính mình.";
                return RedirectToArticleManagement();
            }

            rejectionReason = (rejectionReason ?? string.Empty).Trim();
            if (rejectionReason.Length > 500)
                rejectionReason = rejectionReason.Substring(0, 500);

            if (article != null)
            {
                article.Content = SanitizeArticleContent(article.Content);
            }

            // Gỡ bỏ kiểm tra bắt buộc đối với các trường không có trên giao diện Edit
            ModelState.Remove("CategoryId");
            ModelState.Remove("AuthorId");
            ModelState.Remove("ImageUrl");
            ModelState.Remove("Summary");
            ModelState.Remove("Image");

            PopulateCreateCategories(article != null ? (article.CategoryId ?? existing.CategoryID) : existing.CategoryID);
            ValidateArticleInput(article, imageFile, isAdmin);

            // Kiểm tra danh mục hợp lệ
            if (article != null && (!article.CategoryId.HasValue || !db.Categories.Any(c => c.CategoryID == article.CategoryId.Value)))
            {
                ModelState.AddModelError("CategoryId", "Vui lòng chọn danh mục bài viết hợp lệ.");
                PopulateCreateCategories(article != null ? (article.CategoryId ?? existing.CategoryID) : existing.CategoryID);
            }


            string targetAdminStatus = existing.Status;
            if (isReviewer)
            {
                if (!string.IsNullOrWhiteSpace(submitAction) && ValidStatuses.Contains(submitAction))
                    targetAdminStatus = submitAction;
                else if (article != null && !string.IsNullOrWhiteSpace(article.Status) && ValidStatuses.Contains(article.Status))
                    targetAdminStatus = article.Status;

                if (!isAdmin && (existing.Status != "Pending" ||
                    (targetAdminStatus != "Pending" && targetAdminStatus != "Published" && targetAdminStatus != "Rejected")))
                {
                    ModelState.AddModelError("", "Biên tập viên chỉ được chỉnh sửa bài chờ duyệt và giữ chờ, duyệt hoặc từ chối bài viết.");
                }

                if (targetAdminStatus == "Rejected" && string.IsNullOrWhiteSpace(rejectionReason))
                {
                    ModelState.AddModelError("", "Vui lòng nhập lý do từ chối để người viết biết cần sửa gì.");
                }
            }

            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                TempData["Error"] = "Không thể lưu bài viết: " + string.Join(" | ", errors);

                if (string.IsNullOrWhiteSpace(article.Image))
                    article.Image = existing.ImageUrl;
                if (isEditorUser)
                    article.Status = existing.Status;
                if (!isReviewer)
                    article.Status = existing.Status;

                ViewBag.RejectionReason = string.IsNullOrWhiteSpace(rejectionReason)
                    ? GetRejectionReason(existing.ArticleID)
                    : rejectionReason;
                return View(article);
            }

            existing.CategoryID = article.CategoryId.Value;
            existing.Title = article.Title;
            existing.Content = article.Content;
            existing.Summary = CreateSummary(article.Content);
            existing.UpdatedDate = DateTime.Now;

            if (!isReviewer)
            {
                if (string.Equals(submitAction, "Draft", StringComparison.OrdinalIgnoreCase))
                {
                    existing.Status = "Draft";
                    TempData["Success"] = "Đã lưu chỉnh sửa vào Bản nháp (Draft).";
                }
                else
                {
                    existing.Status = "Pending";
                    TempData["Success"] = "Đã cập nhật nội dung và gửi Admin phê duyệt (Pending).";
                }
            }
            else
            {
                existing.Status = targetAdminStatus;
                TempData["Success"] = "Đã cập nhật bài viết thành công (Trạng thái: " + existing.Status + ").";
            }

            var imageUrl = SaveImage(imageFile);
            if (!string.IsNullOrWhiteSpace(imageUrl))
                existing.ImageUrl = imageUrl;

            db.SaveChanges();

            if (IsArticleAuthorRole() && existing.Status == "Draft")
            {
                SetArticleOwnerUserId(existing.ArticleID, GetCurrentUserId());
            }

            if (existing.Status == "Rejected")
            {
                SetRejectionReason(existing.ArticleID, rejectionReason);
            }
            else if (existing.Status == "Pending" || existing.Status == "Published" || existing.Status == "Archived")
            {
                SetRejectionReason(existing.ArticleID, null);
            }

            // Tự động quay về trang trước đó (hoặc Trang chủ) sau khi lưu/gửi thành công
            return RedirectBackOrHome(returnUrl);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangeWorkflowStatus(int? id, string newStatus, string returnStatus = "", string rejectionReason = "")
        {
            EnsureWorkflowStatusConstraint();

            bool isAdmin = IsAdminUser();
            bool isEditor = IsEditorUser();
            bool isAuthor = IsArticleAuthorRole();
            if (!isAdmin && !isEditor && !isAuthor)
            {
                TempData["Error"] = "Vui lòng đăng nhập tài khoản Admin, Editor hoặc Author.";
                return RedirectToAction("Login", "Account");
            }

            if (!id.HasValue || id.Value <= 0 || string.IsNullOrWhiteSpace(newStatus) || !ValidStatuses.Contains(newStatus))
            {
                TempData["Error"] = "Yêu cầu chuyển trạng thái bài viết không hợp lệ.";
                return RedirectToRoute("AdminArticles", new { action = "Index", status = string.IsNullOrWhiteSpace(returnStatus) ? null : returnStatus });
            }

            var article = db.Articles.Find(id.Value);
            if (article == null)
            {
                TempData["Error"] = "Không tìm thấy bài viết cần cập nhật.";
                return RedirectToRoute("AdminArticles", new { action = "Index", status = string.IsNullOrWhiteSpace(returnStatus) ? null : returnStatus });
            }

            if (!CanEditorEditArticle(article.ArticleID))
            {
                TempData["Error"] = "Bạn chỉ có quyền thay đổi trạng thái bài viết của chính mình.";
                return RedirectToRoute("AdminArticles", new { action = "Index", status = string.IsNullOrWhiteSpace(returnStatus) ? null : returnStatus });
            }

            if (isAuthor)
            {
                bool canSubmit = (article.Status == "Draft" || article.Status == "Rejected") && newStatus == "Pending";
                bool canWithdraw = article.Status == "Pending" && newStatus == "Draft";

                if (!canSubmit && !canWithdraw)
                {
                    TempData["Error"] = "Tác giả chỉ có quyền gửi duyệt bài nháp/bị từ chối hoặc rút bài chờ duyệt về nháp.";
                    return RedirectToRoute("AdminArticles", new { action = "Index", status = string.IsNullOrWhiteSpace(returnStatus) ? null : returnStatus });
                }
            }
            else if (isEditor)
            {
                bool canApprove = article.Status == "Pending" && newStatus == "Published";
                bool canReject = article.Status == "Pending" && newStatus == "Rejected";

                if (!canApprove && !canReject)
                {
                    TempData["Error"] = "Biên tập viên chỉ có thể duyệt hoặc từ chối bài viết đang chờ duyệt.";
                    return RedirectToRoute("AdminArticles", new { action = "Index", status = string.IsNullOrWhiteSpace(returnStatus) ? null : returnStatus });
                }
            }

            rejectionReason = (rejectionReason ?? string.Empty).Trim();
            if (newStatus == "Rejected")
            {
                if (string.IsNullOrWhiteSpace(rejectionReason))
                {
                    TempData["Error"] = "Vui lòng nhập lý do từ chối để người viết biết cần sửa gì.";
                    return RedirectToRoute("AdminArticles", new { action = "Index", status = string.IsNullOrWhiteSpace(returnStatus) ? null : returnStatus });
                }

                if (rejectionReason.Length > 500)
                    rejectionReason = rejectionReason.Substring(0, 500);
            }

            article.Status = newStatus;
            article.UpdatedDate = DateTime.Now;
            db.SaveChanges();

            if (isAuthor && newStatus == "Draft")
            {
                SetArticleOwnerUserId(article.ArticleID, GetCurrentUserId());
            }

            if (newStatus == "Rejected")
            {
                SetRejectionReason(article.ArticleID, rejectionReason);
            }
            else
            {
                SetRejectionReason(article.ArticleID, null);
            }

            switch (newStatus)
            {
                case "Pending":
                    TempData["Success"] = "Đã gửi bài viết #" + article.ArticleID + " sang trạng thái Chờ duyệt (Pending).";
                    break;
                case "Published":
                    TempData["Success"] = "Đã phê duyệt và xuất bản bài viết #" + article.ArticleID + " lên trang chủ (Published).";
                    break;
                case "Rejected":
                    TempData["Success"] = "Đã từ chối bài viết #" + article.ArticleID + " (Lý do: " + rejectionReason + ") — trả về tác giả chỉnh sửa (Rejected).";
                    break;
                case "Archived":
                    TempData["Success"] = "Đã chuyển bài viết #" + article.ArticleID + " vào kho lưu trữ (Archived).";
                    break;
                default:
                    TempData["Success"] = "Đã chuyển bài viết #" + article.ArticleID + " về Bản nháp (Draft).";
                    break;
            }

            return RedirectToRoute("AdminArticles", new { action = "Index", status = string.IsNullOrWhiteSpace(returnStatus) ? null : returnStatus });
        }

        public ActionResult Delete(int? id)
        {
            var denied = CheckArticlePermission("xóa");
            if (denied != null) return denied;

            if (!IsAdminUser())
            {
                TempData["Error"] = "Chỉ Admin mới có quyền xóa bài viết.";
                return RedirectToArticleManagement();
            }

            bool isAdmin = IsAdminUser();
            ViewBag.IsAdminManagement = true;
            ViewBag.IsAdminUser = isAdmin || IsEditorUser();

            if (!id.HasValue || id.Value <= 0)
            {
                TempData["Error"] = "Mã bài viết cần xóa không hợp lệ.";
                return RedirectToArticleManagement();
            }

            var article = db.Articles.Find(id.Value);
            if (article == null)
            {
                TempData["Error"] = "Bài viết cần xóa không tồn tại hoặc đã bị xóa trước đó.";
                return RedirectToArticleManagement();
            }

            if (!CanEditorEditArticle(article.ArticleID))
            {
                TempData["Error"] = "Bạn chỉ có quyền xóa bài viết của chính mình.";
                return RedirectToArticleManagement();
            }

            return View(ToArticleViewModel(article));
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            var denied = CheckArticlePermission("xóa");
            if (denied != null) return denied;

            if (!IsAdminUser())
            {
                TempData["Error"] = "Chỉ Admin mới có quyền xóa bài viết.";
                return RedirectToArticleManagement();
            }

            bool isAdmin = IsAdminUser();
            ViewBag.IsAdminManagement = true;
            ViewBag.IsAdminUser = isAdmin || IsEditorUser();

            if (!id.HasValue || id.Value <= 0)
            {
                TempData["Error"] = "Mã bài viết cần xóa không hợp lệ.";
                return RedirectToArticleManagement();
            }

            var article = db.Articles.Find(id.Value);
            if (article == null)
            {
                TempData["Error"] = "Bài viết không tồn tại hoặc đã bị xóa trước đó.";
                return RedirectToArticleManagement();
            }

            if (!CanEditorEditArticle(article.ArticleID))
            {
                TempData["Error"] = "Bạn chỉ có quyền xóa bài viết của chính mình.";
                return RedirectToArticleManagement();
            }

            try
            {
                db.Articles.Remove(article);
                db.SaveChanges();
                TempData["Success"] = "Đã xóa bài viết thành công.";
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException)
            {
                TempData["Error"] = "Không thể xóa: bài viết còn bình luận hoặc đánh giá liên quan.";
            }
            return RedirectToArticleManagement();
        }

        private Article ToArticleViewModel(Articles article)
        {
            return new Article
            {
                Id = article.ArticleID,
                CategoryId = article.CategoryID,
                Title = article.Title,
                Content = article.Content,
                CreatedDate = article.CreatedDate,
                Image = article.ImageUrl,
                ImageUrl = article.ImageUrl,
                Status = article.Status,
                ViewCount = article.ViewCount
            };
        }

        private string CreateSummary(string content)
        {
            string text = GetPlainText(content);

            if (text.Length <= 180)
                return text;

            return text.Substring(0, 180) + "...";
        }

        private string SaveImage(HttpPostedFileBase imageFile)
        {
            if (imageFile == null || imageFile.ContentLength <= 0)
                return null;

            var extension = Path.GetExtension(imageFile.FileName);
            var fileName = Guid.NewGuid().ToString("N") + extension;
            var folder = Server.MapPath("~/Content/Images/");
            Directory.CreateDirectory(folder);
            imageFile.SaveAs(Path.Combine(folder, fileName));
            return Url.Content("~/Content/Images/" + fileName);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
                db.Dispose();
            base.Dispose(disposing);
        }
    }
}